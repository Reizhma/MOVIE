import os
import datetime
from flask import Flask, render_template, request, redirect, url_for, session, flash
import mysql.connector
from mysql.connector import Error

app = Flask(__name__)
app.secret_key = 'super_secret_movie_key'

# MySQL Configuration
db_config = {
    'host': 'localhost',
    'user': 'root',
    'password': '12345678',
    'database': 'movie_booking'
}
MOVIES = [
    "Angry Birds",
    "Up",
    "WALL-E",
    "Harry Potter",
    "Spider-Man",
    "Kung Fu Panda"
]
INFO = [
    "Experience the hilarious adventures of the Angry Birds as they protect their island from the mischievous green pigs.",
    "A heartwarming adventure of an old man named Carl who travels to South America in his flying house.",
    "A robot named WALL-E embarks on an adventure that could change the destiny of humanity.",
    "A young wizard named Harry Potter discovers his magical powers and attends Hogwarts School of Wizardry.",
    "Peter Parker gains incredible spider-like abilities and becomes the superhero Spider-Man.",
    "Po, a clumsy panda, becomes the Dragon Warrior and learns the art of kung fu."
]
PRICE_PER_SEAT = 250
TIMES = ["10:00 AM", "01:30 PM", "05:00 PM", "08:30 PM"]

def get_db_connection():
    try:
        conn = mysql.connector.connect(**db_config)
        return conn
    except Error as e:
        print(f"Error connecting to MySQL: {e}")
        return None

@app.route('/')
def index():
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return render_template('index.html')

@app.route('/login', methods=['POST'])
def login():
    email = request.form.get('email')
    password = request.form.get('password')
    
    conn = get_db_connection()
    if conn:
        cursor = conn.cursor(dictionary=True)
        cursor.execute("SELECT * FROM users WHERE email = %s AND password = %s", (email, password))
        user = cursor.fetchone()
        cursor.close()
        conn.close()
        
        if user:
            session['user_id'] = user['id']
            session['user_name'] = user['name']
            return redirect(url_for('dashboard'))
    
    flash("Invalid email or password!")
    return redirect(url_for('index'))

@app.route('/register-page')
def register_page():
    return render_template('register.html')

@app.route('/register', methods=['POST'])
def register():
    name = request.form.get('name')
    email = request.form.get('email')
    password = request.form.get('password')
    
    conn = get_db_connection()
    if conn:
        try:
            cursor = conn.cursor()
            cursor.execute("INSERT INTO users (name, email, password) VALUES (%s, %s, %s)", (name, email, password))
            conn.commit()
            cursor.close()
            conn.close()
            flash("Registration successful! Please log in.")
            return redirect(url_for('index'))
        except Error as e:
            flash("Email already registered!")
    return redirect(url_for('register_page'))

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('index'))
    
    movies_data = [{"title": MOVIES[i], "info": INFO[i]} for i in range(len(MOVIES))]
    return render_template('dashboard.html', name=session['user_name'], movies=movies_data)

@app.route('/seat-booking')
def seat_booking():
    if 'user_id' not in session:
        return redirect(url_for('index'))
    
    movie = request.args.get('movie')
    today = datetime.date.today().isoformat()
    date = request.args.get('date', today)
    time = request.args.get('time', TIMES[0])
    
    booked_seats = []
    conn = get_db_connection()
    if conn:
        cursor = conn.cursor()
        cursor.execute("SELECT seats FROM bookings WHERE movie=%s AND show_date=%s AND show_time=%s AND payment_method != 'Cancelled'", (movie, date, time))
        rows = cursor.fetchall()
        for row in rows:
            booked_seats.extend(row[0].split(','))
        cursor.close()
        conn.close()
        
    return render_template('seat-booking.html', movie=movie, today=today, date=date, time=time, times=TIMES, price=PRICE_PER_SEAT, booked_seats=booked_seats)

@app.route('/save-booking', methods=['POST'])
def save_booking():
    if 'user_id' not in session:
        return redirect(url_for('index'))
        
    movie = request.form.get('movie')
    date = request.form.get('date')
    time = request.form.get('time')
    seats = request.form.get('seats')
    
    seat_count = len(seats.split(',')) if seats else 0
    amount = seat_count * PRICE_PER_SEAT
    
    conn = get_db_connection()
    if not conn:
        flash("Database collection error.")
        return redirect(url_for('seat_booking', movie=movie))
        
    cursor = conn.cursor()
    try:
        # ATOMIC TRANSACTION PROTECTION GUARD:
        # Attempt to insert directly using a subquery constraint check. 
        # If any seat string segment matches an active booking row, rowcount returns 0 rows.
        query = """
            INSERT INTO bookings (user_id, movie, show_date, show_time, seats, amount, payment_method)
            SELECT %s, %s, %s, %s, %s, %s, 'Pending'
            FROM DUAL
            WHERE NOT EXISTS (
                SELECT 1 FROM bookings 
                WHERE movie = %s AND show_date = %s AND show_time = %s 
                AND payment_method != 'Cancelled'
                AND (
                    FIND_IN_SET(seats, %s) > 0 OR
                    %s LIKE CONCAT('%%', seats, '%%')
                )
            )
        """
        cursor.execute(query, (session['user_id'], movie, date, time, seats, amount, 
                               movie, date, time, seats, seats))
        conn.commit()
        
        
        if cursor.rowcount == 0:
            conn.rollback()
            print(f"❌ ATOMIC BLOCK: Blocked duplicate attempt on seat {seats}. Bouncing out.")
            cursor.close()
            conn.close()
            return redirect(url_for('seat_booking', movie=movie, date=date, time=time, error="1"))
            
        session['bMovie'] = movie
        session['bDate'] = date
        session['bTime'] = time
        session['bSeats'] = seats
        session['bAmount'] = amount
        session['lastBookingId'] = cursor.lastrowid
        
        cursor.close()
        conn.close()
        return redirect(url_for('payment'))
        
    except Error as e:
        conn.rollback()
        cursor.close()
        conn.close()
        if e.errno == 1062:
            return redirect(url_for('seat_booking', movie=movie, date=date, time=time, error="1"))
        return f"Database integration error: {str(e)}", 500

@app.route('/payment')
def payment():
    if 'user_id' not in session or 'bMovie' not in session:
        return redirect(url_for('dashboard'))
    return render_template('payment.html')

@app.route('/execute-payment', methods=['POST'])
def execute_payment():
    if 'user_id' not in session or 'bMovie' not in session or 'lastBookingId' not in session:
        return redirect(url_for('dashboard'))
        
    method = request.form.get('method')
    
    conn = get_db_connection()
    if conn:
        cursor = conn.cursor()
        cursor.execute("""
            UPDATE bookings 
            SET payment_method = %s 
            WHERE id = %s AND user_id = %s
        """, (method, session['lastBookingId'], session['user_id']))
        conn.commit()
        cursor.close()
        conn.close()
        
        return redirect(url_for('success'))
        
    flash("Database connection error during payment processing.")
    return redirect(url_for('payment'))

@app.route('/success')
def success():
    if 'user_id' not in session or 'lastBookingId' not in session:
        return redirect(url_for('dashboard'))
        
    return render_template('booking-success.html', 
                           bid=session['lastBookingId'], 
                           movie=session['bMovie'], 
                           date=session['bDate'], 
                           time=session['bTime'], 
                           seats=session['bSeats'], 
                           amount=session['bAmount'])

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True, host='127.0.0.1', port=5000, threaded=True)
