import asyncio
import threading
from playwright.async_api import async_playwright

def run_in_thread(user_id, email, password, movie_name, seat_to_select, results):
    """Creates a distinct async loop inside a dedicated OS thread for total concurrency."""
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    loop.run_until_complete(
        run_user_booking(user_id, email, password, movie_name, seat_to_select, results)
    )
    loop.close()

async def run_user_booking(user_id, email, password, movie_name, seat_to_select, results):
    async with async_playwright() as p:
        browser = await p.chromium.launch(headless=False, slow_mo=300, args=["--window-size=800,800"])
        context = await browser.new_context(viewport={"width": 800, "height": 800})
        page = await context.new_page()
        
        session = await context.new_cdp_session(page)
        window_id = (await session.send("Browser.getWindowForTarget"))["windowId"]
        x_pos = 0 if user_id == 1 else 820
        await session.send("Browser.setWindowBounds", {"windowId": window_id, "bounds": {"left": x_pos, "top": 100, "width": 800, "height": 800}})
        
        try:
            print(f"[User {user_id}] Navigating to portal entry point...")
            await page.goto("http://127.0.0.1:5000/", timeout=15000)
            
            print(f"[User {user_id}] Logging in with account: {email}...")
            await page.fill("input[name='email']", email)
            await page.fill("input[name='password']", password)
            await page.click("button[type='submit']")
            
            print(f"[User {user_id}] Authenticated. Finding movie: '{movie_name}'...")
            await page.wait_for_selector(".card", timeout=8000)
            movie_card = page.locator(".card", has=page.locator(f"h2:has-text('{movie_name}')"))
            await movie_card.locator(".btn").click()
            
            print(f"[User {user_id}] Entering seating matrix. Targeting seat: {seat_to_select}...")
            await page.wait_for_selector(f"button.seat:has-text('{seat_to_select}')", timeout=8000)
            
            seat_btn = page.locator(f"button.seat:has-text('{seat_to_select}')")
            
            if await seat_btn.is_disabled() or "taken" in (await seat_btn.get_attribute("class") or ""):
                print(f" [User {user_id}] ROLLBACK: Seat {seat_to_select} visually locked on map array. Returning to movie list dashboard.")
                results[user_id] = "FAILED (Frontend Seat Taken)"
                await page.goto("http://127.0.0.1:5000/") 
                await asyncio.sleep(4.0)
                return

            await seat_btn.click()
            await page.click("button[type='submit']")
            
            await page.wait_for_selector("form[action*='payment']", timeout=4000)
            print(f"[User {user_id}] Confirming payment transaction parameters...")
            await page.click("button[type='submit']")
            
            await page.wait_for_load_state("networkidle", timeout=6000)
            current_url = page.url
            
            if "booking-success" in current_url or "success" in current_url:
                print(f" [User {user_id}] SUCCESS: Claimed seat {seat_to_select}!")
                results[user_id] = "SUCCESS"
                await asyncio.sleep(4.0)
                
            elif "error=1" in current_url or await page.locator(".msg").count() > 0:
                error_msg = await page.locator(".msg").text_content() if await page.locator(".msg").count() > 0 else "Seat taken by someone else"
                print(f" [User {user_id}] ROLLBACK: Rejected by server validation check. Message: '{error_msg.strip()}'. Returning to dashboard view...")
                results[user_id] = "FAILED (Server Validation Rollback)"
                
                await asyncio.sleep(1.5)
                await page.goto("http://127.0.0.1:5000/")
                print(f" [User {user_id}] Rollback complete. State reset to main portal view dashboard layout.")
                await asyncio.sleep(4.0)
            else:
                print(f" [User {user_id}] UNKNOWN STATE: Redirected to {current_url}")
                results[user_id] = f"UNKNOWN ({current_url})"
                await asyncio.sleep(4.0)
                
        except Exception as e:
            print(f" [User {user_id}] ROLLBACK TRIGGERED: Seat conflict or transaction timeout hit -> Redirecting back to dashboard view.")
            results[user_id] = "FAILED (Rollback Handled via Context Exception)"
            
            await asyncio.sleep(1.5)
            await page.goto("http://127.0.0.1:5000/")
            print(f" [User {user_id}] Exception rollback complete. Back at dashboard view index interface.")
            await asyncio.sleep(4.0)
        finally:
            await context.close()
            await browser.close()

def main():
    target_movie = "Angry Birds"
    target_seat = "C7" 
    results = {}
    
    print("====================================================")
    print(f" Launching Parallel Multi-Threaded Concurrency Simulation")
    print(f" Target Movie: {target_movie} |  Target Seat: {target_seat}")
    print("====================================================")
    
    t1 = threading.Thread(target=run_in_thread, args=(1, "ana@gmail.com", "123", target_movie, target_seat, results))
    t2 = threading.Thread(target=run_in_thread, args=(2, "else@gmail.com", "456", target_movie, target_seat, results))
    
    t1.start()
    t2.start()
    
    t1.join()
    t2.join()
    
    print("\n====================================================")
    print(" SIMULATION AGGREGATION METRICS:")
    for uid, status in results.items():
        print(f" -> User {uid}: {status}")
    print("====================================================")

if __name__ == "__main__":
    main()
